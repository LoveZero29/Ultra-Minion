<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyMinions;

use DaPigGuy\PiggyMinions\minions\MinionInformation;
use DaPigGuy\PiggyMinions\minions\MinionType;
use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\Item;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\utils\TextFormat;

class EventListener implements Listener
{
    /** @var PiggyMinions */
    private $plugin;

    public function __construct(PiggyMinions $plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * @ignoreCancelled true
     */
    public function onInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$event->isCancelled()) {
            if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
                $item = $event->getItem();
                $minionItem = Item::fromString((string) PiggyMinions::getInstance()->getConfig()->get("minion-item"));
                if ($item->getId() === $minionItem->getId() && $item->getDamage() === $minionItem->getDamage()) {
                    if (in_array($player->getLevel()->getFolderName(), $this->plugin->getConfig()->get("worlds", []))) {
                        $player->sendMessage(TextFormat::RED . "You can't place minions in this world.");
                        $event->setCancelled();
                        return;
                    }
                    if (($minionInformation = $item->getNamedTag()->getCompoundTag("MinionInformation")) !== null) {
                        if (($minionType = $minionInformation->getCompoundTag("MinionType")) !== null) {
                            if (($actionType = $minionType->getTag("ActionType")) instanceof IntTag && ($targetId = $minionType->getTag("TargetID")) instanceof IntTag) {
                                $targetMeta = $minionType->getInt("TargetMeta", 0);
                                $skin = $player->getSkin();
                                $nbt = Entity::createBaseNBT($event->getBlock()->getSide($event->getFace())->add(0.5, 0, 0.5));
                                $nbt->setTag(new CompoundTag("Skin", [
                                    new StringTag("Name", $skin->getSkinId()),
                                    new ByteArrayTag("Data", $skin->getSkinData()),
                                    new ByteArrayTag("CapeData", $skin->getCapeData()),
                                    new StringTag("GeometryName", $skin->getGeometryName()),
                                    new ByteArrayTag("GeometryData", $skin->getGeometryData())
                                ]));
                                $nbt->setTag((new MinionInformation($player->getUniqueId(), new MinionType($actionType->getValue(), $targetId->getValue(), $targetMeta), $minionInformation->getInt("MinionLevel", 1), $minionInformation->getInt("ResourcesCollected", 0), time()))->toNBT());
                                $entity = Entity::createEntity("MinionEntity", $player->getLevel(), $nbt);
                                $entity->spawnToAll();
                                $player->getInventory()->setItemInHand($item->setCount($item->getCount() - 1));
                                $event->setCancelled();
                            }
                        }
                    }
                }
            }
        }
    }
}