<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyMinions\minions;

use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\IntTag;

class MinionType implements MinionBase
{

    const MINING_MINION = 0;
    const FARMING_MINION = 1;
    const LUMBERJACK_MINION = 2;
    const SLAYING_MINION = 3;

    /** @var int */
    public $actionType;
    /** @var int */
    public $targetId;
    /** @var int */
    public $targetMeta;

    public function __construct(int $actionType, int $targetId, int $targetMeta = 0)
    {
        $this->actionType = $actionType;
        $this->targetId = $targetId;
        $this->targetMeta = $targetMeta;
    }

    public function getActionType(): int
    {
        return $this->actionType;
    }

    public function getTargetId(): int
    {
        return $this->targetId;
    }

    public function getTargetMeta(): int
    {
        return $this->targetMeta;
    }

    public function toNBT(): CompoundTag
    {
        return new CompoundTag("MinionType", [
            new IntTag("ActionType", $this->actionType),
            new IntTag("TargetID", $this->targetId),
            new IntTag("TargetMeta", $this->targetMeta)
        ]);
    }

    public static function fromNBT(CompoundTag $tag): self
    {
        return new self($tag->getInt("ActionType"), $tag->getInt("TargetID"), $tag->hasTag("TargetMeta") ? $tag->getInt("TargetMeta") : 0);
    }
}