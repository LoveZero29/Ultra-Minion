<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyMinions\minions;

use pocketmine\nbt\tag\CompoundTag;

interface MinionBase
{

    public function toNBT(): CompoundTag;

    public static function fromNBT(CompoundTag $tag);

}