<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyMinions\minions;

class MinionUpgrade
{

    // TODO: I don't know

}