<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyMinions\minions;

use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\utils\UUID;

class MinionInformation implements MinionBase
{
    /** @var UUID */
    public $owner;
    /** @var MinionType */
    public $type;
    /** @var int */
    public $level;
    /** @var int */
    public $resourcesCollected;
    /** @var int */
    public $lastSaved;

    public function __construct(UUID $owner, MinionType $type, int $level, int $resourcesCollected, int $lastSaved)
    {
        $this->owner = $owner;
        $this->type = $type;
        $this->level = $level;
        $this->resourcesCollected = $resourcesCollected;
        $this->lastSaved = $lastSaved;
    }

    /**
     * @return UUID
     */
    public function getOwner(): UUID
    {
        return $this->owner;
    }

    public function getType(): MinionType
    {
        return $this->type;
    }

    public function getLevel(): int
    {
        return $this->level;
    }

    public function setLevel(int $level): void
    {
        $this->level = $level;
    }

    public function getResourcesCollected(): int
    {
        return $this->resourcesCollected;
    }

    public function setResourcesCollected(int $resourcesCollected): void
    {
        $this->resourcesCollected = $resourcesCollected;
    }

    public function incrementResourcesCollected(int $amount): void
    {
        $this->resourcesCollected += $amount;
    }

    /**
     * @return int
     */
    public function getLastSaved(): int
    {
        return $this->lastSaved;
    }

    /**
     * @param int $lastSaved
     */
    public function setLastSaved(int $lastSaved): void
    {
        $this->lastSaved = $lastSaved;
    }

    public function toNBT(): CompoundTag
    {
        return new CompoundTag("MinionInformation", [
            new StringTag("OwnerUUID", $this->owner->toString()),
            $this->type->toNBT(),
            new IntTag("MinionLevel", $this->level),
            new IntTag("ResourcesCollected", $this->resourcesCollected),
            new IntTag("LastSaved", $this->lastSaved)
        ]);
    }

    public static function fromNBT(CompoundTag $tag): self
    {
        $type = MinionType::fromNBT($tag->getCompoundTag("MinionType"));
        return new self(UUID::fromString($tag->getString("OwnerUUID")), $type, $tag->getInt("MinionLevel"), $tag->getInt("ResourcesCollected"), $tag->getInt("LastSaved"));
    }
}