<?php
declare(strict_types=1);

namespace DaPigGuy\PiggyMinions\entities;

use DaPigGuy\PiggyMinions\entities\object\MinionTree;
use DaPigGuy\PiggyMinions\PiggyMinions;
use DaPigGuy\PiggyMinions\inventory\MinionInventory;
use DaPigGuy\PiggyMinions\minions\MinionInformation;
use DaPigGuy\PiggyMinions\minions\MinionType;
use DaPigGuy\PiggyMinions\utils\Utils;
use DaPigGuy\PiggyMinions\libs\muqsit\invmenu\InvMenu;
use DaPigGuy\PiggyMinions\libs\muqsit\invmenu\transaction\DeterministicInvMenuTransaction;
use pocketmine\block\Block;
use pocketmine\block\BlockFactory;
use pocketmine\block\BlockIds;
use pocketmine\block\BlockToolType;
use pocketmine\block\Crops;
use pocketmine\entity\EffectInstance;
use pocketmine\entity\Entity;
use pocketmine\entity\Human;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\level\Level;
use pocketmine\level\generator\object\Tree;
use pocketmine\level\particle\DestroyBlockParticle;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\ShortTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\network\mcpe\protocol\AnimatePacket;
use pocketmine\network\mcpe\protocol\LevelEventPacket;
use pocketmine\Player;
use pocketmine\scheduler\ClosureTask;
use pocketmine\utils\Random;
use pocketmine\utils\TextFormat;

class MinionEntity extends Human
{
    const ACTION_IDLE = 0;
    const ACTION_TURNING = 1;
    const ACTION_WORKING = 2;
    const ACTION_FULL_INVENTORY = 3;

    /** @var MinionInformation */
    private $minionInformation;
    /** @var MinionInventory */
    private $minionInventory;
    /** @var int */
    private $currentAction = self::ACTION_IDLE;
    /** @var int */
    private $currentActionTicks = 0;
    /** @var Block|Entity|Tree|null */
    public $target;
    /** @var MinionTree */ 
    private $tree; // Only for Lumberjack minion

    public function __construct(Level $level, CompoundTag $nbt, ?MinionInformation $minionInformation = null)
    {
        $this->minionInformation = $minionInformation;
        parent::__construct($level, $nbt);
	if ($this->minionInformation->getType()->getActionType() === MinionType::LUMBERJACK_MINION) {
	    $this->tree = new MinionTree(BlockFactory::get($this->minionInformation->getType()->getTargetId(), $this->minionInformation->getType()->getTargetMeta()));
	}
    }

    public function initEntity(): void
    {
        parent::initEntity();
        $this->setScale(0.5);
        $this->minionInformation = $this->minionInformation ?? MinionInformation::fromNBT($this->namedtag->getCompoundTag("MinionInformation"));
        $this->minionInventory  = new MinionInventory();
        $tag = $this->namedtag->getTag("MinionInventory");
        if ($tag !== null) {
            $this->minionInventory->setContents(array_map(function (CompoundTag $tag): Item {
                return Item::nbtDeserialize($tag);
            }, $tag->getValue()));
        }
        $this->updateTool();
        if ($this->canAddMoreItem()) {
            $this->currentAction = self::ACTION_IDLE;
            $this->currentActionTicks = 0;
            $this->setNameTag("§l§6MINION\n  §l§e»»•COLLECTING•««");
        }
	if ($this->minionInformation->getType()->getActionType() === MinionType::LUMBERJACK_MINION) {
	    $this->tree = $this->tree ?? new MinionTree(BlockFactory::get($this->minionInformation->getType()->getTargetId(), $this->minionInformation->getType()->getTargetMeta()));
	}
    }

    public function entityBaseTick(int $tickDiff = 1): bool
    {
        $hasUpdate = parent::entityBaseTick($tickDiff);
        if (!$this->closed && !$this->isFlaggedForDespawn() && $this->minionInformation !== null) {
            if ($this->ticksLived % 60 === 0) {
                for ($x = -2; $x <= 2; $x++) { //TODO: Customizable
                    for ($z = -2; $z <= 2; $z++) {
                        if ($x === 0 && $z === 0) continue;
                        $block = $this->level->getBlock($this->add($x, 0, $z));
                        switch ($this->minionInformation->getType()->getActionType()) {
                            case MinionType::FARMING_MINION:
                                if ($block instanceof Crops || $block->getId() === BlockIds::NETHER_WART_PLANT) {
                                    $max = $block instanceof Crops ? 7 : 3;
                                    $block->setDamage($block->getDamage() + 1 < $max ? $block->getDamage() + 1 : $max);
                                    $this->level->setBlock($block, $block);
                                }
                                break;
                            case MinionType::LUMBERJACK_MINION:
                                if ($x % 2 === 0 && $z % 2 === 0) {
                                    if ($block->getId() === BlockIds::SAPLING && $block->getDamage() === $this->tree->sapling->getDamage()) {
                                        $chance = mt_rand(0, 1); // 50%
                                        if ($chance === 1) {
                                            $this->tree->placeObject($this->level, $block->x, $block->y, $block->z, new Random());
                                            break;
                                        }
                                        break;
                                    }
                                }
                                break;
                        }
                    }
                }
            }
            if ($this->target === null) {
                $blocks = [];
                for ($x = -2; $x <= 2; $x++) {
                    for ($z = -2; $z <= 2; $z++) {
                        if ($x === 0 && $z === 0) continue;
                        switch ($this->minionInformation->getType()->getActionType()) {
                            case MinionType::MINING_MINION:
                                $block = $this->level->getBlock($this->add($x, -1, $z));
                                if ($block->getId() === BlockIds::AIR || ($block->getId() === $this->minionInformation->getType()->getTargetId() && $block->getDamage() === $this->minionInformation->getType()->getTargetMeta())) $blocks[] = $block;
                                break;
                            case MinionType::FARMING_MINION:
                                $farmland = $this->level->getBlock($this->add($x, -1, $z));
                                $block = $this->level->getBlock($this->add($x, 0, $z));
                                if (
                                    (in_array($farmland->getId(), [BlockIds::GRASS, BlockIds::DIRT, BlockIds::FARMLAND, BlockIds::SOUL_SAND]) &&
                                        ($this->minionInformation->getType()->getTargetId() !== BlockIds::NETHER_WART_PLANT || $farmland->getId() === BlockIds::SOUL_SAND)
                                    ) && ($block->getId() === BlockIds::AIR || ($block->getId() === $this->minionInformation->getType()->getTargetId() && $block->getDamage() >= ($block instanceof Crops ? 7 : 3)))
                                ) $blocks[] = $block;
                                break;
                            case MinionType::LUMBERJACK_MINION:
                                $dirt = $this->level->getBlock($this->add($x, -1, $z));
                                $block = $this->level->getBlock($this->add($x, 0, $z));
                                if ($x % 2 === 0 && $z % 2 === 0) {
				if (
                                    in_array($dirt->getId(), [BlockIds::DIRT, BlockIds::GRASS, BlockIds::FARMLAND]) && ($block->getId() === BlockIds::AIR || ($block->getId() === $this->minionInformation->getType()->getTargetId() && $block->getDamage() === $this->minionInformation->getType()->getTargetMeta()))
                                ) $blocks[] = $block;
				}
                                break;
                        }
                        if (count($blocks) > 0) $this->target = $blocks[array_rand($blocks)];
                    }
                }
            }
            $this->currentActionTicks++;
            if ($this->target instanceof Block) {
                $this->target = $this->level->getBlock($this->target);
                if (($this->target->getId() !== BlockIds::AIR && $this->target->getId() !== $this->minionInformation->getType()->getTargetId() && $this->target->getDamage() !== $this->minionInformation->getType()->getTargetMeta())  ||
                    (
                        $this->minionInformation->getType()->getActionType() === MinionType::FARMING_MINION && (
                            !in_array($this->target->getLevel()->getBlock($this->target->subtract(0, 1))->getId(), [BlockIds::GRASS, BlockIds::DIRT, BlockIds::FARMLAND, BlockIds::SOUL_SAND]) ||
                            ($this->minionInformation->getType()->getTargetId() !== BlockIds::NETHER_WART_PLANT && $this->target->getLevel()->getBlock($this->target->subtract(0, 1))->getId() === BlockIds::SOUL_SAND)
                        )
                    ) ||
                    (
                        $this->minionInformation->getType()->getActionType() === MinionType::LUMBERJACK_MINION && (
                            !in_array($this->target->getLevel()->getBlock($this->target->subtract(0, 1))->getId(), [BlockIds::DIRT, BlockIds::GRASS, BlockIds::FARMLAND])
                        )
                    )){
                    $this->currentAction = self::ACTION_IDLE;
                    $this->currentActionTicks = 59;
                    $this->target = null;
                }
            }
            switch ($this->currentAction) {
                case self::ACTION_IDLE:
                    if ($this->currentActionTicks >= 60 && $this->target !== null) { //TODO: Customize
                        $this->currentAction = self::ACTION_TURNING;
                        $this->currentActionTicks = 0;
                    }
                    break;
                case self::ACTION_TURNING:
                    $this->lookAt($this->target->multiply($this->currentActionTicks / 5));
                    if ($this->currentActionTicks === 5) {
                        $this->currentAction = self::ACTION_WORKING;
                        $this->currentActionTicks = 0;
                    }
                    break;
                case self::ACTION_WORKING:
                    if ($this->minionInformation->getType()->getActionType() === MinionType::MINING_MINION || $this->minionInformation->getType()->getActionType() === MinionType::FARMING_MINION || $this->minionInformation->getType()->getActionType() === MinionType::LUMBERJACK_MINION) {
                        $isPlacing = $this->target->getId() === BlockIds::AIR;
                        if (!$isPlacing) {
                            if ($this->currentActionTicks === 1) $this->level->broadcastLevelEvent($this->target, LevelEventPacket::EVENT_BLOCK_START_BREAK, (int)(65535 / 60));
                            if ($this->currentActionTicks === 2 && $this->minionInformation->getType()->getActionType() === MinionType::FARMING_MINION && ($this->target instanceof Crops || $this->target->getId() === BlockIds::NETHER_WART_PLANT)) {
                                
         $this->breakBlock($this->target);
                            }
                            $pk = new AnimatePacket();
                            $pk->action = AnimatePacket::ACTION_SWING_ARM;
                            $pk->entityRuntimeId = $this->getId();
                            $this->level->broadcastPacketToViewers($this, $pk);
                        } else {
                            $this->level->broadcastLevelEvent($this->target, LevelEventPacket::EVENT_BLOCK_STOP_BREAK);
                        }
                    }
                    if ($this->currentActionTicks === 60) { //TODO: Customizable
                        if (!$this->target instanceof Block) break;
                        if ($this->minionInformation->getType()->getActionType() === MinionType::LUMBERJACK_MINION) {
			    if ($this->target->getId() !== BlockIds::AIR) {
                                for ($y = 0; $y < 3; $y++) {
                                    $block = $this->target->getLevel()->getBlock($this->target->add(0, $y));
				    if ($block->getId() !== $this->minionInformation->getType()->getTargetId() || $block->getDamage() !== $this->minionInformation->getType()->getTargetMeta()) break;
                                    $this->breakBlock($block);
                                }
			    } else $this->breakBlock($this->target);
                        } else $this->breakBlock($this->target);
			    $this->currentAction = self::ACTION_IDLE;
                            $this->currentActionTicks = 0;
                            $this->target = null;
                            if (!$this->canAddMoreItem()) {
                                $this->currentAction = self::ACTION_FULL_INVENTORY;
                                
       $this->currentActionTicks = 0;
                                $this->setNameTag(TextFormat::RED . "My Inventory Is Now Full :<!");
                            }
                    }
                    break;
                case self::ACTION_FULL_INVENTORY:
                    if ($this->canAddMoreItem()) {
                        $this->currentAction = self::ACTION_IDLE;
                        $this->currentActionTicks = 0;
                        $this->setNameTag("");
                    }
                    break;
            }
        }
        return $hasUpdate;
    }

    private function breakBlock(Block $block)
    {
        $this->level->broadcastLevelEvent($block, LevelEventPacket::EVENT_BLOCK_STOP_BREAK);
        $this->level->addParticle(new DestroyBlockParticle($this->target->add(0.5, 0.5, 0.5), $block));
        $this->level->setBlock($block, $block->getId() === BlockIds::AIR ? ($this->minionInformation->getType()->getActionType() === MinionType::LUMBERJACK_MINION ? $this->tree->sapling : BlockFactory::get($this->minionInformation->getType()->getTargetId(), $this->minionInformation->getType()->getTargetMeta())) : BlockFactory::get(BlockIds::AIR));
        $drops = $block->getDropsForCompatibleTool(ItemFactory::get(ItemIds::AIR));
        if (empty($drops)) $drops = $this->target->getSilkTouchDrops(ItemFactory::get(ItemIds::AIR));
        $this->minionInventory->addItem(...$drops);
        foreach ($drops as $drop) {
            $this->minionInformation->incrementResourcesCollected($drop->getCount());
        }
    }
    
public function updateTool(){
        $tier = ucwords(PiggyMinions::getInstance()->getConfig()->get("tier-tool", "diamond"));
        $isNetherite = $tier === "Netherite";
        switch ($this->minionInformation->getType()->getActionType()) {
            case MinionType::MINING_MINION:
                $block = BlockFactory::get($this->minionInformation->getType()->getTargetId(), $this->minionInformation->getType()->getTargetMeta());
                $tools = [
                    BlockToolType::TYPE_NONE => $isNetherite ? ItemFactory::get(745) : ItemFactory::fromString($tier . " Pickaxe"),
                    BlockToolType::TYPE_SHOVEL => $isNetherite ? ItemFactory::get(744) : ItemFactory::fromString($tier . " Shovel"),
                    BlockToolType::TYPE_PICKAXE => $isNetherite ? ItemFactory::get(745) : ItemFactory::fromString($tier . " Pickaxe"),
                    BlockToolType::TYPE_AXE => $isNetherite ? ItemFactory::get(746) : ItemFactory::fromString($tier . " Axe"),
                    BlockToolType::TYPE_SHEARS => ItemFactory::get(ItemIds::SHEARS)
                ];
                $this->inventory->setItemInHand($tools[$block->getToolType()]);
                break;
            case MinionType::FARMING_MINION:
                $this->inventory->setItemInHand($isNetherite ? ItemFactory::get(747) : ItemFactory::fromString($tier . " Hoe"));
                break;
            case MinionType::LUMBERJACK_MINION:
                $this->inventory->setItemInHand($isNetherite ? ItemFactory::get(746) : ItemFactory::fromString($tier . " Axe"));
                break;
            case MinionType::SLAYING_MINION:
                $this->inventory->setItemInHand($isNetherite ? ItemFactory::get(743) : ItemFactory::fromString($tier . " Sword"));
                break;
        }
    }

    public function getName(): string
    {
        return "Minion";
    }

    public function attack(EntityDamageEvent $source): void
    {
        if ($source instanceof EntityDamageByEntityEvent) {
            $damager = $source->getDamager();
            if ($damager instanceof Player && $damager->getUniqueId()->equals($this->minionInformation->getOwner())) {
                $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
                $menu->setName("§l§6Minion " . Utils::getRomanNumeral($this->minionInformation->getLevel()));
                $menu->getInventory()->setContents(array_fill(0, 54, Item::get(Item:: INVISIBLE_BEDROCK)->setCustomName(TextFormat::RESET)));
                $menu->getInventory()->setItem(21, Item::get(Item::AIR));
                $menu->getInventory()->setItem(22, Item::get(Item::AIR));
                $menu->getInventory()->setItem(23, Item::get(Item::AIR));
                $menu->getInventory()->setItem(24, Item::get(Item::AIR));
                $menu->getInventory()->setItem(25, Item::get(Item::AIR));
                $menu->getInventory()->setItem(30, Item::get(Item::AIR));
                $menu->getInventory()->setItem(31, Item::get(Item::AIR));
                $menu->getInventory()->setItem(32, Item::get(Item::AIR));
                $menu->getInventory()->setItem(33, Item::get(Item::AIR));
                $menu->getInventory()->setItem(34, Item::get(Item::AIR));
                $menu->getInventory()->setItem(39, Item::get(Item::AIR));
                $menu->getInventory()->setItem(40, Item::get(Item::AIR));
                $menu->getInventory()->setItem(41, Item::get(Item::AIR));
                $menu->getInventory()->setItem(42, Item::get(Item::AIR));
                $menu->getInventory()->setItem(43, Item::get(Item::AIR));
                $menu->getInventory()->setItem(48, Item::get(Item::CHEST)->setCustomName("§r§l§eCollect Items\n\n§r§3Click To Collect All\nThe Items From Your\nMinion Inventory\n\n§r§l§aClick To Collect"));
                $menu->getInventory()->setItem(50, Item::get(Item::BOTTLE_O_ENCHANTING)->setCustomName(TextFormat::AQUA . "§r§l§eUpgrade Minion\n\n§r§3Click To Upgrade Your\nMinion To Next Level\n\n§r§l§aClick To Upgrade")->setLore([$this->minionInformation->getLevel() < 15 ? "§r§l§eCost: " . TextFormat::GOLD . $this->getLevelUpCost() : "§r§l§3Reached Max Level"]));
                $menu->getInventory()->setItem(52, Item::get(Item::REDSTONE_BLOCK)->setCustomName("§r§l§ePickup Minion\n\n§r§3Click To Pickup Your\nMinion From Current\nLocation\n\n§r§l§aClick To Pickup"));
                for ($i = $this->minionInformation->getLevel(); $i < 15; $i++) {
                    $menu->getInventory()->setItem((int)(21 + ($i % 5) + (9 * floor($i / 5))), Item::get(Item::WATER)->setCustomName(TextFormat::YELLOW . "Unlock at level " . TextFormat::GOLD . Utils::getRomanNumeral(($i + 1))));
                }
                foreach ($this->minionInventory->getContents(true) as $slot => $item) {
                    $menu->getInventory()->setItem((int)(21 + ($slot % 5) + (9 * floor($slot / 5))), $item);
                }
                $menu->setListener(InvMenu::readonly(function(DeterministicInvMenuTransaction $transaction): void {
                        $player = $transaction->getPlayer();
	                $itemClicked = $transaction->getItemClicked();
	                $itemClickedWith = $transaction->getItemClickedWith();
	                $action = $transaction->getAction();
                    switch ($action->getSlot()) {
                        case 48:
                            foreach (array_reverse($this->minionInventory->getContents(), true) as $slot => $item) {
                                if ($player->getInventory()->canAddItem($item)) {
                                    $player->getInventory()->addItem($item);
                                    $this->minionInventory->setItem($slot, Item::get(Item::AIR));
                                } else {
                                    $player->sendMessage(TextFormat::RED . "Your Inventory Is Full, Empty It Before Making A Transaction");
                                }
                            }
                            break;
                        case 50:
                            $player->removeWindow($action->getInventory());
                            if ($this->minionInformation->getLevel() < 15) {
                                if (PiggyMinions::getInstance()->getEconomyProvider()->getMoney($player) - $this->getLevelUpCost() >= 0) {
                                    PiggyMinions::getInstance()->getEconomyProvider()->takeMoney($player, $this->getLevelUpCost());
                                    $this->minionInformation->setLevel($this->minionInformation->getLevel() + 1);
                                    $player->sendMessage(TextFormat::GREEN . "Your Minion Has Been Upgraded To Level " . TextFormat::GOLD . Utils::getRomanNumeral($this->minionInformation->getLevel()));
                                    $this->minionInventory->setSize($this->minionInformation->getLevel());
                                } else {
                                    $player->sendMessage(TextFormat::RED . "You Don't Have Enough Money To Level Up!");
                                }
                            } else {
                                $player->sendMessage(TextFormat::RED . "Your Minion Has Reached The Maxed Level!");
                            }
                            break;
                        case 52:
                            $player->removeWindow($action->getInventory());
                            $this->minionInventory->dropContents($this->level, $this);
                            $minionItem = Item::fromString((string) PiggyMinions::getInstance()->getConfig()->get("minion-item"));
                            if (is_array($minionItem)) $minionItem = $minionItem[0];
                            $minionItem->setNamedTagEntry($this->minionInformation->toNBT());
                            $minionItem->setCustomName("§r§l§2Minion");
                            $minionItem->setNamedTagEntry(new ListTag(Item::TAG_ENCH));
                            $this->level->dropItem($this, $minionItem);
                            foreach ($this->minionInventory->getContents() as $slot => $item) {
                                $this->level->dropItem($this, $item);
                            }
                            $this->flagForDespawn();
                            break;
                        default:
                            for ($i = 0; $i <= 15; $i++) {
                                if ($i > $this->minionInformation->getLevel() - 1) continue;
                                $slot = (int)(21 + ($i % 5) + (9 * floor($i / 5)));
                                if ($action->getSlot() === $slot) {
                                    if ($player->getInventory()->canAddItem($itemClicked)) {
                                        $player->getInventory()->addItem($itemClicked);
                                        $remaining = $itemClicked->getCount();
                                        /** @var Item $item */
                                        foreach (array_reverse($this->minionInventory->all($itemClicked), true) as $slot => $item) {
                                            $itemCount = $item->getCount();
                                            $this->minionInventory->setItem($slot, $item->setCount($itemCount - $remaining > 0 ? $itemCount - $remaining : 0));
                                            $remaining -= $itemCount;
                                            if ($remaining === 0) break;
                                        }
                                    } else {
                                        $player->removeWindow($action->getInventory());
                                        $player->sendMessage(TextFormat::RED . "Your Inventory Is Full, Empty It Before Making A Transaction");
                                    }
                                }
                            }
                            break;
                    }
                }));
                $menu->send($damager);
                $taskId = PiggyMinions::getInstance()->getScheduler()->scheduleRepeatingTask(new ClosureTask(function (int $currentTick) use ($menu): void {
                    foreach ($this->minionInventory->getContents(true) as $slot => $item) {
                        $menu->getInventory()->setItem((int)(21 + ($slot % 5) + (9 * floor($slot / 5))), $item);
                    }
                }), 1)->getTaskId();
                $menu->setInventoryCloseListener(function (Player $player, Inventory $inventory) use ($taskId): void {
                    PiggyMinions::getInstance()->getScheduler()->cancelTask($taskId);
                });
            }
        }
    }

private function canAddMoreItem(): bool
    {
        $contents = $this->minionInventory->getContents();
        if (empty($contents)) return true;
        foreach ($contents as $slot => $item) {
            $i = clone $item;
            $i->setCount(1);
            if ($this->minionInventory->canAddItem($i)) {
                return true;
            }
    return false;
        }
    }
    
    public function MinionInformation(MinionInformation $minionInformation)
        {
if($this->minionInformation->getLevel() == 1){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 2){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 3){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                     }elseif($this->minionInformation->getLevel() == 4){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(24, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 5){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(24, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(25, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 6){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(24, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(25, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(30, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 7){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(24, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(25, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(30, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(31, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 8){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(24, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(25, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(30, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(31, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(32, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 9){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(24, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(25, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(30, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(31, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(32, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(33, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 10){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(24, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(25, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(30, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(31, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(32, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(33, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(34, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 11){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(24, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(25, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(30, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(31, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(32, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(33, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(34, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(39, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 12){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(24, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(25, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(30, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(31, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(32, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(33, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(34, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(39, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(40, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 13){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(24, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(25, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(30, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(31, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(32, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(33, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(34, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(39, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(40, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(41, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 14){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(24, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(25, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(30, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(31, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(32, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(33, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(34, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(39, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(40, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(41, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(42, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }elseif($this->minionInformation->getLevel() == 15){
                        $menu->getInventory()->setItem(21, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(22, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(23, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(24, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(25, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(30, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(31, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(32, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(33, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(34, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(39, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(40, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(41, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(42, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        $menu->getInventory()->setItem(43, Item::get(Item::AIR)->setCustomName(TextFormat::RESET));
                        }
}

    private function getLevelUpCost(): int
    {
        $costs = (array) PiggyMinions::getInstance()->getConfig()->get("levelup-costs");
        return (int) $costs[$this->minionInformation->getLevel()];
    }

    public function move(float $dx, float $dy, float $dz): void
    {
        //NOOP
    }

    public function addEffect(EffectInstance $effect): bool
    {
        return false;
    }

    public function saveNBT(): void
    {
        parent::saveNBT();
        $this->minionInformation->setLastSaved(time());
        $this->namedtag->setTag($this->minionInformation->toNBT());
    }
}
