<?php
declare(strict_types=1);

namespace DaPigGuy\PiggyMinions;

use DaPigGuy\PiggyMinions\libs\DaPigGuy\libPiggyEconomy\libPiggyEconomy;
use DaPigGuy\PiggyMinions\libs\DaPigGuy\libPiggyEconomy\providers\EconomyProvider;
use DaPigGuy\PiggyMinions\entities\MinionEntity;
use DaPigGuy\PiggyMinions\libs\muqsit\invmenu\InvMenu;
use DaPigGuy\PiggyMinions\libs\muqsit\invmenu\InvMenuHandler;
use pocketmine\entity\Entity;
use pocketmine\plugin\PluginBase;

class PiggyMinions extends PluginBase
{
    /** @var PiggyMinions */
    private static $instance;
    
    /** @var EconomyProvider */
    private $economyProvider;
    
    public function onLoad(): void
    {
    	self::$instance = $this;
    }
    
    public function onEnable(): void
    {
    	foreach ([libPiggyEconomy::class, InvMenu::class] as $class) {
            if (!class_exists($class)) {
                $this->getLogger()->error($class . " virion not found. Please download PiggyMinions from Poggit-CI or use DEVirion (not recommended).");
                $this->getServer()->getPluginManager()->disablePlugin($this);
                return;
            }
        }
        if(!InvMenuHandler::isRegistered()) InvMenuHandler::register($this);
        Entity::registerEntity(MinionEntity::class, true);
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
        if (is_null($this->getServer()->getPluginManager()->getPlugin("InvCrashFix"))) {
	    $this->getLogger()->notice("InvCrashFix is required to fix client crashes on 1.16, download it here: https://poggit.pmmp.io/ci/Muqsit/InvCrashFix");
	}
	if ($this->getConfig()->get("config-version") !== 1) {
            $this->getLogger()->notice("Your configuration file is outdated, updating the config.yml...");
            $this->getLogger()->notice("The old configuration file can be found at config.old.yml");
            rename($this->getDataFolder() . "config.yml", $this->getDataFolder() . "config.old.yml");
            $this->saveDefaultConfig();
            $this->reloadConfig();
        }
        $this->saveDefaultConfig();
        libPiggyEconomy::init();
        $this->economyProvider = libPiggyEconomy::getProvider($this->getConfig()->get("economy"));
	$this->updateMinions();
    }
    
    public static function getInstance(): PiggyMinions
    {
        return self::$instance;
    }
    
    public function getEconomyProvider(): EconomyProvider
    {
        return $this->economyProvider;
    }
    
    private function updateMinions()
    {
        foreach ($this->getServer()->getLevels() as $level) {
            if (in_array($level->getFolderName(), $this->getConfig()->get("worlds", []))) continue;
            foreach ($level->getEntities() as $entity) {
                if ($entity instanceof MinionEntity) {
                    $entity->updateTool();
                }
            }
        }
    }
}
