<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyMinions\libs\DaPigGuy\libPiggyEconomy\exceptions;

class UnknownProviderException extends \Exception
{

}